# Pre-Registration Plan (2026-11-24 17:58:16)
- Primary metric: Test macro-F1 (mean ± std over 5 seeds: [13, 21, 42, 87, 101])
- Checkpoint & BEST selection: Strictly on DEV macro-F1 and trainable % (test never used)
- Leakage control: Intra-train duplicates and train/dev/test overlaps removed from train only
- Imbalance handling: Applied strictly to train split; SMOTE compared fairly inside frozen-encoder setting
- Significance tests: Paired bootstrap (2,000 resamples, 95% CI) + exact McNemar (median p) + Holm correction

## Methodological Note: BERT Pooler Parity Fix
- Kannada dev diagnostic (seed=42) showed MuRIL LoRA collapsed to majority class (12.46% dev F1) because PEFT freezes bert.pooler by default, whereas XLM-R keeps its equivalent 768x768 dense layer trainable inside classifier.
- Applied modules_to_save=['classifier', 'pooler'] uniformly to BERT-family models (mbert, muril).

## BEST Configuration Decision
- Selected on DEV only: {'model': 'mbert', 'tuning': 'full'} (mean dev macro-F1 = 48.61%, within 1.0 pt of top 48.61%, trainable_pct = 100.000%, mean time = 4.96 min).
